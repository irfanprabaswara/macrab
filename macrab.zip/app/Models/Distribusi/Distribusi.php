<?php

namespace App\Models\Distribusi;

use Illuminate\Database\Eloquent\Model;

class Distribusi extends Model
{
    //
}
