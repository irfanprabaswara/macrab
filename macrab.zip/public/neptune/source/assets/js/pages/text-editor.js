$(document).ready(function() {
    
    "use strict";
    $('#summernote').summernote({
        height: 400
    });
});